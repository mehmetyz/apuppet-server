function RemoteKeyboard(remoteChat, gestureController, divGesture) {
    this.remoteChat = remoteChat;
    this.manage = false;

    this.gestureController = gestureController;
    this.divGesture = divGesture;
    this.isJoyStick = false;

    this.x = null;
    this.y = null;

    this.keyList = {
        w: false,
        a: false,
        s: false,
        d: false
    }

    this.startTime = 0;

    var obj = this;  // for event handlers

    ui.on('RemoteChat.onManagementStart', function () {
        this.manage = true;
    }, this);

    ui.on('RemoteChat.onManagementStop', function () {
        this.manage = false;
    }, this);

    this.setJoystickOn = function (state) {
        this.isJoyStick = state;
    }

    this.setUp = function () {
        obj.x = 255;
        obj.y = 255;

    }

    $(document).on('keydown', function (e) {

        if (!obj.isJoyStick) {
            if (!obj.manage || e.altKey || e.ctrlKey ||
                !(e.key.length == 1 || e.key === 'Backspace' || e.key === 'Delete' || e.key === 'Enter' ||
                    e.key === 'ArrowLeft' || e.key === 'ArrowRight' || e.key === 'Home' || e.key === 'End')) {
                return;
            }

            var encodedKey = e.key.replace('%', '%25').replace(',', '%2C');
            obj.remoteChat.sendData(`key,${encodedKey}`);
            e.preventDefault();
            e.stopPropagation();
        }

        else {
            if (obj.x === null && obj.y === null) {
                obj.setUp();


                let tempX = Math.floor(obj.x);
                let tempY = Math.floor(obj.y);

                obj.gestureController.gestureStart(tempX, tempY);
            }

            e.preventDefault();
            obj.keyList[e.key.toLowerCase()] = true;

            if (obj.keyList.a) obj.x -= 5;
            if (obj.keyList.d) obj.x += 5;
            if (obj.keyList.w) obj.y -= 5;
            if (obj.keyList.s) obj.y += 5;

            //obj.remoteChat.sendData(`swipe,${Math.floor(obj.x)},${Math.floor(obj.y)},${Math.floor(obj.nextX)},${Math.floor(obj.nextY)},10`);
            //obj.gestureController.gestureFinish(Math.floor(obj.x), Math.floor(obj.y));


        }
    }).on('keyup', function (e) {

        obj.gestureController.gestureFinish(Math.floor(obj.x), Math.floor(obj.y));
        const key = e.key.toLowerCase();
        if (key === 'a' || key === 'w' || key === 's' || key === 'd')
            obj.keyList[key] = false;

        if (obj.keyList.a === false &&
            obj.keyList.w === false &&
            obj.keyList.s === false &&
            obj.keyList.d === false) {
            obj.x = null;
            obj.y = null;
        }
    });
}
